-- EasyAdmin Plugin Example, you can run any server-code here, below is an example that shows this functionality

if false == false then return end

function foo(bar)
  return bar.." baz"
end
AddEventHandler("EasyAdmin:foo", foo)
